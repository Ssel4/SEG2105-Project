package com.example.walkinclinicsservicesapp;

import android.widget.Button;
import android.widget.EditText;

import androidx.test.annotation.UiThreadTest;
import androidx.test.rule.ActivityTestRule;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

public class LogInTest {

    @Rule
    public ActivityTestRule<LogIn> logInActivityTestRule= new ActivityTestRule<LogIn>(LogIn.class);
    private LogIn logIn=null;



    private EditText userName ,email;



    @Before
    public void setUp() throws Exception {
        logIn=logInActivityTestRule.getActivity();
    }





    @Test
    @UiThreadTest
    public void checkName() throws Exception{

        userName=logIn.findViewById(R.id.editTextUserName);
        userName.setText("admin");
        assertNotNull(logIn.findViewById(R.id.editTextUserName));
        assertEquals("admin",userName.getText().toString());
        assertNotEquals("admin1",userName.getText().toString());
    }


    @Test
    @UiThreadTest
    public void checkEmail() throws Exception{

        email=logIn.findViewById(R.id.editTextEmail);
        email.setText("email@gmail.com");
        assertNotNull(email.findViewById(R.id.editTextEmail));
        assertEquals("email@gmail.com",email.getText().toString());
        assertNotEquals("email22@gmail.com",email.getText().toString());
    }
}
