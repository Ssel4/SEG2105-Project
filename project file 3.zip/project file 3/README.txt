x
GitHub link: 
https://github.com/Ssel4/SEG2105-Project

Members:
Alessandro Miguel Tirado, 8349209


can create admin for testing. in final version this will not be possible.

Didn't finish adding the update feature for the schedule.