package com.example.walkinclinicsservicesapp;

import java.util.List;

public interface IService {



    //gets the name of the service
    String getServiceName();

    //get the role of the employee
    public String getEmployeeRole();



}
